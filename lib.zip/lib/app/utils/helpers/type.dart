part of app_helpers;

// this file focused on enum data

enum TaskType {
  todo,
  inProgress,
  done,
}
