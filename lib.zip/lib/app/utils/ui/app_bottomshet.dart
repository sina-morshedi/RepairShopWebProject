part of ui_utils;

// contains all bottomsheet templates
class AppBottomSheet {}
