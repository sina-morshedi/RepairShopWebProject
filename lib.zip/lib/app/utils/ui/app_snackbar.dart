part of ui_utils;

/// contains all snackbar templates
class AppSnackbar {}
