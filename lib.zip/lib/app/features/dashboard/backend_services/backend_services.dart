part of dashboard;

class backend_services {

  void showMessage(String message, {BuildContext? context}) {
    if (kIsWeb && context != null) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(message)),
      );
    } else {
      Fluttertoast.showToast(msg: message);
    }
  }

  Future<List<_users>> fetchAllProfile() async {
    final String backendUrl = ApiEndpoints.getAllProfile;

    try {
      final response = await http.get(Uri.parse(backendUrl));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);

        if (data is List) {
          return data.map((e) => _users.fromJson(e)).toList();
        }

        else if (data is Map<String, dynamic>) {
          return [_users.fromJson(data)];
        }

        else {
          Fluttertoast.showToast(msg: 'Unexpected response format');
          // showMessage("Unexpected response format", context: context);
          return [];
        }
      } else {
        final data = jsonDecode(response.body);
        String error = data['error'] ?? 'Fetch failed';
        Fluttertoast.showToast(msg: error);
        return [];
      }
    } catch (e) {
      Fluttertoast.showToast(msg: 'Error: ${e.toString()}');
      return [];
    }
  }

}
